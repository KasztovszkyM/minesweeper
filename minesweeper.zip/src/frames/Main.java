package frames;
import javax.swing.*;

public class Main {

	public static void main(String[] args) {
		JFrame game = new GameFrame(16,16);
		game.setVisible(true);

	}

}
